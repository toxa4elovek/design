-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 25 2013 г., 16:02
-- Версия сервера: 5.1.44
-- Версия PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `gdev`
--

-- --------------------------------------------------------

--
-- Структура таблицы `avatars`
--

CREATE TABLE IF NOT EXISTS `avatars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `model_id` int(10) NOT NULL,
  `filekey` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `avatars`
--


-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `default_timelimit` int(10) NOT NULL,
  `shortTimelimit` int(10) NOT NULL,
  `shortestTimelimit` int(10) NOT NULL,
  `smallIncreseTimelimit` int(10) NOT NULL,
  `largeIncreaseTimelimit` int(10) NOT NULL,
  `minAward` int(10) NOT NULL DEFAULT '0',
  `normalAward` int(10) NOT NULL,
  `goodAward` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `title`, `default_timelimit`, `shortTimelimit`, `shortestTimelimit`, `smallIncreseTimelimit`, `largeIncreaseTimelimit`, `minAward`, `normalAward`, `goodAward`) VALUES
(1, 'Логотип', 10, 7, 4, 13, 16, 5500, 11000, 22000),
(2, 'Web-баннер', 7, 4, 2, 10, 12, 3000, 4900, 8100),
(3, 'Сайт', 17, 12, 8, 22, 26, 7000, 15000, 25000),
(4, 'Флаер', 7, 4, 2, 10, 12, 3500, 7000, 15000),
(5, 'Фирменный стиль', 8, 4, 2, 12, 14, 9500, 21000, 45000),
(6, 'Страница СоцСети', 7, 4, 2, 10, 12, 3500, 7000, 15000),
(7, 'Копирайтинг', 14, 10, 6, 18, 22, 5000, 14000, 38000),
(8, 'Буклет', 14, 7, 4, 23, 26, 5500, 11000, 22000),
(9, 'Иллюстрация', 10, 4, 2, 14, 16, 3000, 4900, 6600),
(10, 'Другое', 10, 5, 3, 15, 18, 3000, 11000, 22000),
(11, 'Упаковка', 14, 7, 4, 21, 24, 7000, 26800, 53600),
(12, 'Реклама', 14, 7, 4, 21, 24, 13400, 26800, 53600);

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `pitch_id` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `solution_id` int(10) unsigned NOT NULL,
  `reply_to` int(10) NOT NULL,
  `text` text NOT NULL,
  `history` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`pitch_id`,`solution_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `pitch_id`, `created`, `solution_id`, `reply_to`, `text`, `history`) VALUES
(1, 1, 1, '2013-06-25 19:20:40', 0, 0, '#1, bla bla', ''),
(2, 1, 1, '2013-06-25 19:23:21', 0, 0, '#1, bla bla', ''),
(3, 1, 1, '2013-06-25 19:23:35', 0, 0, '#1 bla bla', ''),
(4, 1, 1, '2013-06-25 19:23:57', 0, 0, 'bla bla bla #1 bla bla #2 bla', ''),
(5, 1, 1, '2013-06-25 19:24:19', 0, 0, '\r\nПортрет пользователя Тестер Т.\r\n25.06.13 19:23\r\nbla bla bla #1, bla bla #2 ,bla ', ''),
(6, 2, 1, '2013-06-25 20:00:40', 4, 0, '#4, ', '');

-- --------------------------------------------------------

--
-- Структура таблицы `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `type` varchar(255) NOT NULL,
  `pitch_id` int(10) unsigned NOT NULL,
  `user_id` int(10) NOT NULL,
  `solution_id` int(10) NOT NULL,
  `comment_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pitch_id` (`pitch_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `events`
--

INSERT INTO `events` (`id`, `created`, `type`, `pitch_id`, `user_id`, `solution_id`, `comment_id`) VALUES
(1, '2013-06-25 19:20:40', 'CommentAdded', 1, 1, 0, 1),
(2, '2013-06-25 19:23:21', 'CommentAdded', 1, 1, 0, 2),
(3, '2013-06-25 19:23:35', 'CommentAdded', 1, 1, 0, 3),
(4, '2013-06-25 19:23:57', 'CommentAdded', 1, 1, 0, 4),
(5, '2013-06-25 19:24:19', 'CommentAdded', 1, 1, 0, 5),
(6, '2013-06-25 19:45:05', 'SolutionAdded', 1, 2, 1, 0),
(7, '2013-06-25 19:52:36', 'SolutionAdded', 1, 2, 2, 0),
(8, '2013-06-25 19:53:51', 'SolutionAdded', 1, 2, 3, 0),
(9, '2013-06-25 20:00:26', 'SolutionAdded', 1, 2, 4, 0),
(10, '2013-06-25 20:00:40', 'CommentAdded', 1, 2, 4, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `experts`
--

CREATE TABLE IF NOT EXISTS `experts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `spec` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `experts`
--

INSERT INTO `experts` (`id`, `name`, `title`, `spec`, `text`, `user_id`, `price`) VALUES
(1, 'Альберт Федченко', 'Генеральный директор рекламного агентства <a href="http://lafedja.ru" target="_blank">LaFedja</a>', 'Упаковка, логотип, фирменный стиль, сайт, печатная продукция (буклеты, брошюры)', '<p>Закончил художественно-графический факультет Кубанского Государственного Университета.</p>\r\n<p>Более 10 лет преподает в Кубанском государственном университете на факультете Архитектуры и дизайна. Интерес к творческой части компьютерных технологий проявил еще в эру черно-белых мониторов. Студентом, на заре компьютерной графики России, стал занимать первые места международных конкурсов и фестивалей. На данный момент совмещает преподавательскую деятельность с работой в ведущем дизайн-агентстве Краснодара <a href="http://lafedja.ru" target="_blank">LaFedja</a>.</p>\r\n<p>Каждый день просматривает и анализирует cотни новых работ лучших мировых агентств и дизайнеров в области графического дизайна, упаковки и веб-технологий. С появлением Интернета считает возможность самообучения безграничными.</p>', '33', 1000),
(3, 'Сергей Кожара', 'Креативный директор и совладелец студии визуального продакшена <a href="http://jara.specialone.ru" target="_blank">Special One</a>', 'Реклама, иллюстрация, фоторетушь, копирайтинг, баннеры, флаеры, разработка персонажей', '<p>Закончил художественно-графический факультет СПбГПУ. С 2000 по 2006 год работал арт-директором и и.о. креативного директора в рекламном агентстве &laquo;БизнесЛинк&raquo;. С 2006 по 2011 год работал арт-директором в рекламном агентстве &laquo;Небо&raquo; и вошел в рейтинг наиболее награждаемых арт-директоров России. В 2011 году основал Special One Visual Production, который специализируется на фото-пост-продакшене. В рамках Special One создал неповторимый стиль для матчевых афиш для ФК &laquo;Зенит&raquo;. Сергей работал с брендами: Chupa-Chups, Fazer, Jameson, &laquo;Балтимор&raquo;, &laquo;Балтика&raquo;, &laquo;Мегафон&raquo;, банк &laquo;ТРАСТ&raquo; и др. Является финалистом и призером многочисленных фестивалей рекламы.</p>', '74', 1000),
(2, 'Владимир Павлов', 'Соучредитель рекламного агентства «Протеин», в прошлом — исполнительный директор р/а «Родная речь» Leo Burnett Group', 'Копирайтинг, реклама, фирменный стиль', '<p>Окончил курс окончил курс Executive MBA по&nbsp;стратегическому маркетингу в&nbsp;Британском Открытом Университете. Работает в рекламе с 1996 года. В 1997 году Владимир был назначен руководителем по работе с клиентами в Bates Saatchi &amp; Saatchi Украина. С 1999 по 2004 гг. &mdash; был аккаунт директором в Saatchi &amp; Saatchi Estonia. С 2004 по 2011 год возглавлял петербургское рекламное агентство &laquo;Небо&raquo;. Под его руководством, &laquo;Небо&raquo; стало креативным агентством номер 1 в Петербурге и в 2009 году вошло в TOP 10 российских рекламных агентств (по версии AKAP). В 2011 году возглавил &laquo;<a href="http://www.rore.ru" target="_blank">Родную речь</a>&raquo;,&nbsp;которое&nbsp;входит в состав Leo Burnett Group; а с&nbsp;марта 2013 года &mdash; генеральный директор и соучредитель рекламного агентства &laquo;<a href="http://proteingroup.ru" target="_blank">Протеин</a>&raquo;.&nbsp;Владимир Павлов в разное время работал с такими клиентами, как Toyota, Procter &amp; Gamble, Hewlett-Packard, Альфа-банк, банк &laquo;ТРАСТ&raquo;, Vimm-Bill-Dann, Audi, Valio и другие.</p>', '36', 1000),
(4, 'Михаил Чернышев', 'Маркетинг директор <a href="http://www.tele2.hr/privatni-korisnici/v02/" target="_blank">Tele-2, Хорватия</a> ', 'Реклама', '<p>Михаил окончил курс Executive MBA по&nbsp;стратегическому маркетингу в&nbsp;Стокгольмской Школе Экономики. Работал с такими клиентами, как Richemont, Puma, Pernod Ricard, Alcatel, Binatone, Nestle. С&nbsp;апреля 2006 по&nbsp;июнь 2010 года занимал&nbsp;позицию медиа-менеджера, а&nbsp;затем &mdash; маркетинг-директора в TELE2-Россия, а с 2010 перешел на работу в&nbsp;хорватский офис <a title="Tele 2, Хорватия" href="http://www.tele2.hr/privatni-korisnici/v02/">TELE2</a>.</p>', '', 1000),
(5, 'Максим Нестеренко', 'Куратор курса Графического дизайна в <a href="http://artfobia.tumblr.com/" target="_blank">Высшей Британской Школе Дизайна</a>', 'Логотипы, реклама, иллюстрация, графический дизайн', '<p>Куратор курса Графического дизайна в <a href="http://artfobia.tumblr.com/">Высшей Британской Школе Дизайна</a>.</p>\r\n<p>Максим закончил Московский Университет дизайна и технологии и Университет прикладных искусств и дизайна в Вене. Работает в дизайне с 1990 года: в 1998 был старшим арт-директором в рекламном агентстве Leo Burnett, с 2002 выступал в роли креативного директора в 5 агентствах, в том числе и РА &laquo;Приор&raquo;. Работал с такими брендами как Panasonic, Salamander, Carrier, Aiko, Toshiba, OKI, AIWA.</p>\r\n<p>Куратор курса Графического Дизайна на отделении дополнительного профессионального образования и куратор Культурных исследований (Critical &amp; Cultural Studies) в Британской Высшей Школе Дизайна.</p>\r\n<p>Участник Международных и Всероссийских художественных выставок с 1988 г. Творческие работы находятся в галереях и частных коллекциях в России, Японии, Австрии, США, Германии и Словакии. Победитель Adobe Europe design сompetition в категории Create (1997 г.). Призёр и номинант столичных рекламных фестивалей. Член жюри ММФР.</p>', '468', 1000),
(6, 'Станислав Ефремов', 'Основатель, управляющий партнер и арт-директор креативного агентства <a href="http://www.none.ru/" target="_blank">nOne</a>', 'Логотипы, фирменный стиль, сайт, печатная продукция (упаковка, буклеты, брошюры), иллюстрация, реклама', '<p>Основатель, управляющий партнер и арт-директор креативного агентства <a title="nOne" href="http://www.none.ru/">nOne</a>.</p>\r\n<p>Более 10 лет возглавляет творческое подразделение агентства nOne. Решает креативные задачи в области товарного и территориального брендинга, презентационного дизайна, интерактивных и рекламных коммуникаций компаний Вимм-Билль-Данн, Газпромбанк, Intel, Motorola, Северсталь, Росатом, FSC, Трансаэро и многих других. Руководил созданием брендов Смоленска и Воронежа.</p>\r\n<p>Придерживается инженерного подхода к решению творческих вопросов без лишней декоративности, но с остроумием. &laquo;Стараюсь найти идеальный баланс между функциональностью и красотой, интересами клиента и агентства, &mdash; комментирует Станислав. &mdash; Каждый, кто входит в нашу команду &mdash; это трендсеттер. Я предлагаю клиенту то, к чему придут конкуренты через пару лет&raquo;.</p>\r\n<p>Вдохновляется архитектурой, электронной музыкой, современным дизайном, классическим кино и пинг-понгом &mdash; &laquo;ни дня без новых впечатлений&raquo;!</p>', '120', 1000),
(7, 'Валентин Перция', 'Генеральный директор компании <a href=" http://blogbrandaid.com/" target="_blank">BrandAid</a>', 'Нейминг, копирайтинг, стратегия, фирменный стиль', '<p>Генеральный директор компании <a href="http://blogbrandaid.com/" target="_blank">BrandAid</a> (Москва, Киев). Красный диплом Киевского Высшего Военного Авиационно-Инженерного Училища по специальности матобеспечение АСУ, 1991 год. В рекламе и маркетинге с 1993 года.</p>\r\n<p>С 1995 года работа в международных РА (Euro RSCG World Wide, Ark/JWT, Bates Ukraine) на позициях от стратегического планировщика до заместителя директора. В 2000 году создал компанию BrandAid. C 2004 года работает офис в Москве. Специализация &ndash; создание и развитие брендов. Компания разработала более 100 новых брендов (Мягков, Сильпо, Винодел и так далее) и продолжает развиваться.</p>\r\n<p>Автор книги &laquo;Брендинг: Курс молодого бойца&raquo; (издательство &laquo;Питер&raquo;, Россия, 2005г.). Соавтор книги &laquo;Анатомия бренда&raquo; (издательство &laquo;Вершина&raquo;, Россия, Москва, 2007 г.), Соавтор книги &laquo;Удвоение продаж&raquo; (Издательство &laquo;Эксмо&raquo;, Москва, 2010 г.). Разработчик программы обучения по созданию бренда &ldquo;Анатомия Бренда&rdquo;, которую прошло более 2000 человек в пяти странах бывшего СССР за 8 лет.</p>', '1991', 9200),
(8, 'Дмитрий Макаров', 'Креативный директор <a href="http://www.great.ru/" target="_blank">Great</a>', 'Копирайтинг, реклама', '<div>\r\n<div><strong id="internal-source-marker_0.5233653241302818"><span>Родился и вырос в Ленинграде. Работал в Рок-клубе, Формальном Театре. Вот уже 14 лет креативный директор р/а&nbsp;<a title="Great" href="http://www.great.ru/">Great</a>.&nbsp;</span></strong><strong id="internal-source-marker_0.5233653241302818"><span>Выступал в качестве жюри на различных рекламных фестивалях. Принимал участие в разработке рекламных кампаний для Футбольного клуба Зенит, пива Fosters, пива &laquo;Балтика&raquo;, пива Old Bobby, <strong id="internal-source-marker_0.5233653241302818"><span>&laquo;</span></strong>Альфа Банк<strong id="internal-source-marker_0.5233653241302818"><span>&raquo;</span></strong>, <strong id="internal-source-marker_0.5233653241302818"><span><strong id="internal-source-marker_0.5233653241302818"><span>&laquo;</span></strong></span></strong>Теремок<strong id="internal-source-marker_0.5233653241302818"><span>&raquo;</span></strong>, кофе Jardin, чай Greenfield, Isover, Knauf, квас <strong id="internal-source-marker_0.5233653241302818"><span><strong id="internal-source-marker_0.5233653241302818"><span>&laquo;</span></strong></span></strong>Хлебный Край<strong id="internal-source-marker_0.5233653241302818"><span><strong id="internal-source-marker_0.5233653241302818"><span>&raquo;</span></strong></span></strong>, Sinebruchoff и пр. Женат. Многодетный отец.</span></strong></div>\r\n<div><strong><span><br /></span></strong></div>\r\n<div><strong><span><br /></span></strong></div>\r\n</div>', '1768', 1000);

-- --------------------------------------------------------

--
-- Структура таблицы `favourites`
--

CREATE TABLE IF NOT EXISTS `favourites` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pitch_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `favourites`
--


-- --------------------------------------------------------

--
-- Структура таблицы `grades`
--

CREATE TABLE IF NOT EXISTS `grades` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `referer` varchar(255) NOT NULL,
  `partner_rating` int(1) NOT NULL,
  `work_rating` int(1) NOT NULL,
  `site_rating` int(1) NOT NULL,
  `type` varchar(10) NOT NULL,
  `pitch_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '0',
  `short` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pitch_id` (`pitch_id`,`user_id`),
  KEY `enabled` (`enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `grades`
--


-- --------------------------------------------------------

--
-- Структура таблицы `historycomments`
--

CREATE TABLE IF NOT EXISTS `historycomments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `pitch_id` int(10) unsigned NOT NULL,
  `created` datetime NOT NULL,
  `solution_id` int(10) unsigned NOT NULL,
  `reply_to` int(10) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`pitch_id`,`solution_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `historycomments`
--


-- --------------------------------------------------------

--
-- Структура таблицы `historysolutions`
--

CREATE TABLE IF NOT EXISTS `historysolutions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `pitch_id` int(10) NOT NULL,
  `created` datetime NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`pitch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `historysolutions`
--


-- --------------------------------------------------------

--
-- Структура таблицы `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pitch_id` int(10) NOT NULL,
  `note` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `notes`
--


-- --------------------------------------------------------

--
-- Структура таблицы `pitches`
--

CREATE TABLE IF NOT EXISTS `pitches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(10) unsigned NOT NULL,
  `user_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `industry` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `business-description` text NOT NULL,
  `started` datetime NOT NULL,
  `finishDate` datetime NOT NULL,
  `totalFinishDate` datetime NOT NULL,
  `ideas_count` int(10) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` int(2) NOT NULL DEFAULT '0',
  `split` tinyint(1) unsigned DEFAULT '0',
  `awarded` int(10) NOT NULL,
  `pinned` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `expert` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `private` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `social` tinyint(1) NOT NULL DEFAULT '0',
  `expert-ids` text NOT NULL,
  `email` tinyint(1) NOT NULL DEFAULT '0',
  `timelimit` int(2) NOT NULL DEFAULT '0',
  `brief` tinyint(1) NOT NULL DEFAULT '0',
  `phone-brief` varchar(255) NOT NULL,
  `guaranteed` int(2) NOT NULL DEFAULT '0',
  `materials` tinyint(1) NOT NULL,
  `materials-limit` varchar(255) NOT NULL,
  `fileFormats` text NOT NULL,
  `fileFormatDesc` text NOT NULL,
  `filesId` text NOT NULL,
  `fileDesc` text NOT NULL,
  `specifics` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `billed` tinyint(1) NOT NULL,
  `views` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `status` (`status`),
  KEY `expert` (`expert`),
  KEY `awarded` (`awarded`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `pitches`
--

INSERT INTO `pitches` (`id`, `category_id`, `user_id`, `title`, `industry`, `description`, `business-description`, `started`, `finishDate`, `totalFinishDate`, `ideas_count`, `price`, `total`, `fee`, `status`, `split`, `awarded`, `pinned`, `expert`, `private`, `social`, `expert-ids`, `email`, `timelimit`, `brief`, `phone-brief`, `guaranteed`, `materials`, `materials-limit`, `fileFormats`, `fileFormatDesc`, `filesId`, `fileDesc`, `specifics`, `published`, `billed`, `views`) VALUES
(1, 1, 1, 'Проверка редактируемости файлов', 'фывф', 'Что вы хотите получить на выходе от дизайнера?  Что должно быть прописано в логотипе?  Кто ваши клиенты/потребители/покупатели?  Где будет это размещаться?фвфывфывфыв', 'Опишите в двух словах ваш род деятельности. Какие качества отличают ваш бизнес от конкурентов?', '2013-06-21 15:54:53', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, 6000.00, 7620.00, 0.00, 0, 0, 0, 0, 0, 0, 0, 'a:0:{}', 0, 0, 1, '+7', 0, 0, 'допустимая стоимость одного изображения', 'a:1:{i:0;s:2:"AI";}', 'Дополнительная информация о файлах: размер, разрешение', 'a:1:{i:0;s:2:"17";}', '', 'a:2:{s:9:"qualities";s:64:"Прагматичный, надежный, элегантный";s:15:"logo-properties";a:7:{i:0;s:1:"5";i:1;s:1:"5";i:2;s:1:"5";i:3;s:1:"5";i:4;s:1:"5";i:5;s:1:"5";i:6;s:1:"5";}}', 1, 1, 2),
(2, 1, 1, 'Логотип', 'Бла бла бла', 'Что вы хотите получить на выходе от дизайнера?  Что должно быть прописано в логотипе?  Кто ваши клиенты/потребители/покупатели?  Где будет это размещаться?', 'Опишите в двух словах ваш род деятельности. Какие качества отличают ваш бизнес от конкурентов?', '2013-06-25 16:46:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 6000.00, 8570.00, 0.00, 0, 0, 0, 0, 0, 0, 0, 'a:0:{}', 0, 0, 1, '+7', 1, 0, 'допустимая стоимость одного изображения', 'a:0:{}', 'Дополнительная информация о файлах: размер, разрешение', 'a:1:{i:0;s:2:"14";}', '', 'a:2:{s:9:"qualities";s:64:"Прагматичный, надежный, элегантный";s:15:"logo-properties";a:7:{i:0;s:1:"1";i:1;s:1:"1";i:2;s:1:"1";i:3;s:1:"1";i:4;s:1:"1";i:5;s:1:"1";i:6;s:1:"1";}}', 0, 0, 0),
(3, 1, 1, 'проверка', 'проверка', 'Что вы хотите получить на выходе от дизайнера?  Что должно быть прописано в логотипе?  Кто ваши клиенты/потребители/покупатели?  Где будет это размещаться?', 'Опишите в двух словах ваш род деятельности. Какие качества отличают ваш бизнес от конкурентов?', '2013-06-25 16:50:33', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 6000.00, 7620.00, 0.00, 0, 0, 0, 0, 0, 0, 0, 'a:0:{}', 0, 0, 1, '111', 0, 0, 'допустимая стоимость одного изображения', 'a:0:{}', 'Дополнительная информация о файлах: размер, разрешение', 'a:2:{i:0;s:2:"15";i:1;s:2:"16";}', '', 'a:2:{s:9:"qualities";s:64:"Прагматичный, надежный, элегантный";s:15:"logo-properties";a:7:{i:0;s:1:"5";i:1;s:1:"5";i:2;s:1:"5";i:3;s:1:"5";i:4;s:1:"5";i:5;s:1:"5";i:6;s:1:"5";}}', 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `pitchfiles`
--

CREATE TABLE IF NOT EXISTS `pitchfiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `model_id` int(10) NOT NULL,
  `filekey` varchar(255) NOT NULL,
  `file-description` varchar(255) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `pitchfiles`
--

INSERT INTO `pitchfiles` (`id`, `filename`, `model`, `model_id`, `filekey`, `file-description`, `user_id`) VALUES
(1, '', '', 0, '', '', 0),
(2, '', '', 0, '', '', 0),
(3, '', '', 0, '', '', 0),
(4, '/Users/dima/www/gdev/app/webroot/pitchfiles/chexkbox.png', '\\app\\models\\Pitch', 4, 'files', '', 0),
(5, '/Users/dima/www/gdev/app/webroot/pitchfiles/chexkbox.png', '\\app\\models\\Pitch', 5, 'files', '', 0),
(6, '/Users/dima/www/gdev/app/webroot/pitchfiles/category copy.png', '\\app\\models\\Pitch', 6, 'files', '', 0),
(7, '/Users/dima/www/gdev/app/webroot/pitchfiles/congrats.png', '\\app\\models\\Pitch', 7, 'files', '', 0),
(8, '/Users/dima/www/gdev/app/webroot/pitchfiles/change_photo.jpg', '\\app\\models\\Pitch', 8, 'files', 'проверка', 0),
(9, '/Users/dima/www/gdev/app/webroot/pitchfiles/category copy.png', '\\app\\models\\Pitch', 9, 'files', '', 1),
(10, '/Users/dima/www/gdev/app/webroot/pitchfiles/change_password.png', '\\app\\models\\Pitch', 10, 'files', '', 1),
(11, '/Users/dima/www/gdev/app/webroot/pitchfiles/click_on_photo.png', '\\app\\models\\Pitch', 11, 'files', 'пояснение 2', 1),
(12, '/Users/dima/www/gdev/app/webroot/pitchfiles/buyers_pilot.png', '\\app\\models\\Pitch', 12, 'files', '', 1),
(13, '', '', 0, '', '', 1),
(14, '/Users/dima/www/gdev/app/webroot/pitchfiles/buyers_pilot_hover.png', '\\app\\models\\Pitch', 14, 'files', '', 1),
(15, '/Users/dima/www/gdev/app/webroot/pitchfiles/change_password.png', '\\app\\models\\Pitch', 15, 'files', 'описание файла', 1),
(16, '/Users/dima/www/gdev/app/webroot/pitchfiles/buyers_pilot_hover.psd', '\\app\\models\\Pitch', 16, 'files', '', 1),
(17, '/Users/dima/www/gdev/app/webroot/pitchfiles/change_password.png', '\\app\\models\\Pitch', 17, 'files', 'текст пояснения', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `short` text NOT NULL,
  `full` text NOT NULL,
  `tags` text NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `imageurl` varchar(255) NOT NULL,
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `views` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `title`, `short`, `full`, `tags`, `user_id`, `imageurl`, `published`, `created`, `views`) VALUES
(55, 'Проверка', '<p>проверка</p>', '<p>проверка</p>', 'заказчикам|дизайнерам', 1, '', 0, '2013-06-25 14:30:46', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `promocodes`
--

CREATE TABLE IF NOT EXISTS `promocodes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `expires` datetime NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `pitch_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `promocodes`
--


-- --------------------------------------------------------

--
-- Структура таблицы `ratingchanges`
--

CREATE TABLE IF NOT EXISTS `ratingchanges` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `solution_id` int(10) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `ratingchanges`
--


-- --------------------------------------------------------

--
-- Структура таблицы `receipts`
--

CREATE TABLE IF NOT EXISTS `receipts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pitch_id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10314 ;

--
-- Дамп данных таблицы `receipts`
--

INSERT INTO `receipts` (`id`, `pitch_id`, `name`, `value`) VALUES
(10258, 4, 'Награда Дизайнеру', 6000),
(10259, 4, 'Закрытый питч', 0),
(10260, 4, 'Рекламный Кейс', 0),
(10261, 4, '“Прокачать” бриф', 0),
(10262, 4, 'Установлен срок', 0),
(10263, 4, 'Заполнение брифа', 750),
(10264, 4, 'Гарантированный питч', 950),
(10265, 4, 'Сбор GoDesigner', 870),
(10274, 5, 'Награда Дизайнеру', 6000),
(10275, 5, 'Закрытый питч', 0),
(10276, 5, 'Рекламный Кейс', 0),
(10277, 5, '“Прокачать” бриф', 0),
(10278, 5, 'Установлен срок', 0),
(10279, 5, 'Заполнение брифа', 750),
(10280, 5, 'Гарантированный питч', 950),
(10281, 5, 'Сбор GoDesigner', 870),
(10290, 1, 'Награда Дизайнеру', 6000),
(10291, 1, 'Закрытый питч', 0),
(10292, 1, 'Рекламный Кейс', 0),
(10293, 1, '“Прокачать” бриф', 0),
(10294, 1, 'Установлен срок', 0),
(10295, 1, 'Заполнение брифа', 750),
(10296, 1, 'Гарантированный питч', 0),
(10297, 1, 'Сбор GoDesigner', 870),
(10298, 2, 'Награда Дизайнеру', 6000),
(10299, 2, 'Закрытый питч', 0),
(10300, 2, 'Рекламный Кейс', 0),
(10301, 2, '“Прокачать” бриф', 0),
(10302, 2, 'Установлен срок', 0),
(10303, 2, 'Заполнение брифа', 750),
(10304, 2, 'Гарантированный питч', 950),
(10305, 2, 'Сбор GoDesigner', 870),
(10306, 3, 'Награда Дизайнеру', 6000),
(10307, 3, 'Закрытый питч', 0),
(10308, 3, 'Рекламный Кейс', 0),
(10309, 3, '“Прокачать” бриф', 0),
(10310, 3, 'Установлен срок', 0),
(10311, 3, 'Заполнение брифа', 750),
(10312, 3, 'Гарантированный питч', 0),
(10313, 3, 'Сбор GoDesigner', 870);

-- --------------------------------------------------------

--
-- Структура таблицы `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pitch_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `created` datetime NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `requests`
--


-- --------------------------------------------------------

--
-- Структура таблицы `solutionfiles`
--

CREATE TABLE IF NOT EXISTS `solutionfiles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `originalbasename` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `model_id` int(10) NOT NULL,
  `filekey` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `solutionfiles`
--


-- --------------------------------------------------------

--
-- Структура таблицы `solutions`
--

CREATE TABLE IF NOT EXISTS `solutions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `pitch_id` int(10) NOT NULL,
  `created` datetime NOT NULL,
  `copyrightedMaterial` tinyint(1) NOT NULL DEFAULT '0',
  `copyrightedInfo` text NOT NULL,
  `description` text NOT NULL,
  `rating` int(10) NOT NULL DEFAULT '0',
  `views` int(10) NOT NULL DEFAULT '0',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `likes` int(10) NOT NULL DEFAULT '0',
  `num` int(10) NOT NULL,
  `awarded` tinyint(1) NOT NULL,
  `nominated` tinyint(1) NOT NULL,
  `step` int(2) NOT NULL,
  `change` datetime NOT NULL,
  `selected` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`,`pitch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `solutions`
--


-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `model_id` int(10) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date` datetime NOT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `tasks`
--


-- --------------------------------------------------------

--
-- Структура таблицы `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ORDER` varchar(255) NOT NULL,
  `RESULT` varchar(255) NOT NULL,
  `RC` varchar(255) NOT NULL,
  `TERMINAL` varchar(255) NOT NULL,
  `CURRENCY` varchar(255) NOT NULL,
  `INT_REF` varchar(255) NOT NULL,
  `AUTHCODE` varchar(255) NOT NULL,
  `PAN` varchar(255) NOT NULL,
  `TRTYPE` varchar(255) NOT NULL,
  `TIMESTAMP` varchar(255) NOT NULL,
  `AMOUNT` varchar(255) NOT NULL,
  `SIGN_CALLBACK` varchar(255) NOT NULL,
  `FUNCTION` varchar(255) NOT NULL,
  `RRN` varchar(255) NOT NULL,
  `TEXTMESSAGE` varchar(255) NOT NULL,
  `CARDHOLDERNAME` varchar(255) NOT NULL,
  `ACS` varchar(255) NOT NULL,
  `USER_IP` varchar(255) NOT NULL,
  `SIGN` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ORDER` (`ORDER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `transactions`
--


-- --------------------------------------------------------

--
-- Структура таблицы `urls`
--

CREATE TABLE IF NOT EXISTS `urls` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `short` varchar(255) NOT NULL,
  `full` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `urls`
--


-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `oldemail` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `confirmed_email` tinyint(1) NOT NULL,
  `token` varchar(255) NOT NULL,
  `facebook_uid` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `lastTimeOnline` datetime NOT NULL,
  `invited` tinyint(1) NOT NULL DEFAULT '0',
  `paymentOptions` text NOT NULL,
  `userdata` text NOT NULL,
  `isClient` tinyint(1) NOT NULL,
  `isDesigner` tinyint(1) NOT NULL,
  `isCopy` tinyint(1) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `email_newpitch` tinyint(1) NOT NULL DEFAULT '1',
  `email_newcomments` tinyint(1) NOT NULL DEFAULT '1',
  `email_newpitchonce` tinyint(1) NOT NULL DEFAULT '0',
  `email_newsolonce` tinyint(1) NOT NULL DEFAULT '0',
  `email_newsol` tinyint(1) NOT NULL DEFAULT '0',
  `email_digest` tinyint(1) NOT NULL DEFAULT '0',
  `silenceCount` int(10) NOT NULL,
  `silenceUntil` datetime NOT NULL,
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `lastActionTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `oldemail`, `first_name`, `last_name`, `password`, `active`, `confirmed_email`, `token`, `facebook_uid`, `created`, `lastTimeOnline`, `invited`, `paymentOptions`, `userdata`, `isClient`, `isDesigner`, `isCopy`, `isAdmin`, `email_newpitch`, `email_newcomments`, `email_newpitchonce`, `email_newsolonce`, `email_newsol`, `email_digest`, `silenceCount`, `silenceUntil`, `banned`, `lastActionTime`) VALUES
(1, 'tester@gmail.com', '', 'Тестер', 'Тестер', '37e9a48ebceccc5054dfdc52a03c182c2e3fd7cb0c4fe129c9ca07b2e6f9f197d3aaef6bf4ad1f0280be68b0fc5da11a5e5e4e7163286db03c11bde4039410b3', 1, 0, '51c43bebdf319', '', '2013-06-21 15:41:31', '2013-06-25 19:19:30', 0, '', '', 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '2013-06-25 19:27:22'),
(2, 'tester2@gmail.com', '', 'Тестер2', 'Тестер2', '37e9a48ebceccc5054dfdc52a03c182c2e3fd7cb0c4fe129c9ca07b2e6f9f197d3aaef6bf4ad1f0280be68b0fc5da11a5e5e4e7163286db03c11bde4039410b3', 1, 0, '51c9b704668e1', '', '2013-06-25 19:28:04', '2013-06-25 19:33:15', 0, '', '', 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '2013-06-25 20:00:40');
